#ifndef LCS_H
#define LCS_H


class LCS
{
    public:
        LCS();
        virtual ~LCS();

    protected:

    private:
};

#endif // LCS_H
