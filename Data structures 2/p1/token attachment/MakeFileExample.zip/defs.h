/*
 * a header file
 * */

int x;
