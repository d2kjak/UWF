#ifndef _linkedList_h
#define _linkedList_h

typedef struct node Node;

void store(char *fName);

#endif