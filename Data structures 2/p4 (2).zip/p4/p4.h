#ifndef _p4
#define _p4



double *item;
int max;
int count;

typedef struct LinkList Link;
typedef struct AdjListNode AdjList;

Link* initLink(double);
AdjList* initAdjList(double);
void readBinInfo();
void addToCurrentBin(double, AdjList*);
int nextFit(double[], int);
AdjList* addNextFit(double, AdjList*);
int firstFit(double[], int);
AdjList* addFirstFit(double, AdjList*);
void printItems(double[], int);



#endif