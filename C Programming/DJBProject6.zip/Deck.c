/*
 * File:   Deck.c
 * Author: djj5
 *
 * Created on April 8, 2015, 12:59 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Deck.h"
#include "Card.h"
#include "Hand.h"
/*
 *
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

void initDeck(DeckT *deck){

    /*
    cardT card;
    int x;

    for (x=0; x < 52; x++){

        (*deck).cards[x] = initCard(card, x);
        deck.count++
    }
    */
}


void shuffleDeck(DeckT *deck){

    int num, i, temp;
    CardT x;
    for(i=0; i<52; i++){
    srand( (int) time(NULL));

    temp = rand() % 51;
    num = temp;

    deck.cards[num] = deck.cards[i];
    x = deck.cards[num];
    deck.cards[i] = x;

    }
}


CardT dealOneFromDeck(DeckT *deck){
    int num = rand() % 51;
    deck.count --;
    return deck.cards[num];


}

void displayDeck(const DeckT *deck){



    int i;
    for(i=0; i<52; i++){
        displayCard(deck.cards[i]);
    }


}
