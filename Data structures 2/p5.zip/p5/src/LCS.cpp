#include "LCS.h"

LCS::LCS()
{
    //ctor
}

LCS::~LCS()
{
    //dtor
}
