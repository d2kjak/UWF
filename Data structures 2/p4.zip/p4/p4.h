#ifndef _p4
#define _p4



double *item;
int max;
int count;

typedef struct LinkList Link;
typedef struct AdjListNode AdjList;

Link* initLink(int);
AdjList* initAdjList(int);
void initWeightArray(int);
void readBinInfo();
void addToCurrentBin(int, AdjList*);
int nextFit(double[], int);
AdjList* addNextFit(int, AdjList*);
void firstFit(int[]);
void printItems(double[]);



#endif