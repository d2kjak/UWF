/*
 * File:   Card.c
 * Author: djj5
 *
 * Created on April 8, 2015, 12:59 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Deck.h"
#include "Card.h"
#include "Hand.h"


#define Clubs 0
#define Diamonds 1
#define Spades 2
#define Hearts 3
#define Error -1

/*
 *
 */
/*
CardT initCard(CardT, int);
int compareCard(CardT, CardT);
void displayCard(CardT);
*/

int main(int argc, char** argv) {


    return (EXIT_SUCCESS);
}

CardT initCard(CardT card, int num){


    card.number = num;

    if (num >= 0 && num <= 12) {
        card.suit = Clubs;
    }
    else if (num >= 13 && num <= 25){
        card.suit = Diamonds;
    }
    else if (num >= 26 && num <= 38){
        card.suit = Spades;
    }
    else if (num >= 39 && num <= 51) {
        card.suit = Hearts;
    }
    else {
        card.suit = Error;
    }


    if (card.suit == Clubs){
        card.value = num - 0;

    }
    else if (card.suit == Diamonds) {
        card.value = num - 13;
    }
    else if (card.suit == Spades) {
        card.value = num - 26;
    }
    else  {
        card.value = num - 39;
    }

    return card;
}

int compareCard(CardT card1, CardT card2){

    int result;

    if (card1.value > card2.value){
        result = 1;
    }
    else if (card1.value < card2.value){
        result = -1;
    }
    else {
        result = 0;
    }

    return result;
}


void displayCard(CardT card){

    char vArray[13] = "23456789TJQKA";
    char sArray[4][9] = {"CLUBS", "DIAMONDS", "SPADES", "HEARTS"};
    char cArray[2][7] = {"(RED)", "(BLACK)"};
    if(card.suit == 0 || card.suit == 2)
    {

        printf("%c of %s %s %i\n", vArray[card.value],
              sArray[card.suit], cArray[1], card.number);
    }
    else if(card.suit == 1 || card.suit == 3)
    {
        printf("%c of %s %s %i\n", vArray[card.value],
              sArray[card.suit], cArray[0], card.number);
    }


}




