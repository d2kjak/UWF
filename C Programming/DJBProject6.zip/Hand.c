/*
 * File:   Hand.c
 * Author: djj5
 *
 * Created on April 8, 2015, 12:59 PM
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Deck.h"
#include "Card.h"
#include "Hand.h"

/*
 *
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

void initHand(HandT *hand)
{
    hand.count = 0;
}

void addToHand(HandT *hand, CardT card)
{
        hand.cards[hand->count] = card;
        hand.count=hand.count+1;

}

void sortHand(HandT *hand)
{
    int fillHand;
    int pos1;
    int pos2;

    CardT temp;
    for(fillHand=0; fillHand <= hand->count-2; fillHand++)
    {
        pos1 = fillHand;
        for(pos2 = fillHand; pos2 <= hand.count-1; pos2++)
        {
            if(hand.cards[pos2].value < hand.cards[pos1].value)
                pos1 = pos2;
        }
        if(pos1 != fillHand)
        {
            temp = hand.cards[pos1];
            hand.cards[pos1] = hand.cards[fillHand];
            hand.cards[fillHand] = temp;
        }
    }
}

void displayHand(HandT *hand)
{
    int i;

    for(i=0; i < hand.count; i++)
        displayCard(hand.cards[i]);
}



