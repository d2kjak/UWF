#ifndef events
#define events
#include <stdio.h>
#include <stdlib.h>

void event();

#endif